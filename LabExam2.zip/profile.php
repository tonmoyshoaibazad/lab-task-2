<?php
	session_start();

?>

<fieldset>
    <legend><b>PROFILE</b></legend>
	<form action="#" method="post">
		<br/>
		<table cellpadding="0" cellspacing="0">
			<tr>
				<td>Name</td>
				<td>:</td>
				<td><?php echo $_SESSION["username"];?></td>
				<td rowspan="7" align="center">
					<img width="128" src="../image/user.png"/>
                    <br/>
                    <a href="mahin.jpg">Change</a>
				</td>
			</tr>		
			<tr><td colspan="3"><hr/></td></tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td>bob@aiub.edu</td>
			</tr>		
			<tr><td colspan="3"><hr/></td></tr>			
			<tr>
				<td>Gender</td>
				<td>:</td>
				<td>Male</td>
			</tr>
			<tr><td colspan="3"><hr/></td></tr>
			<tr>
				<td>Date of Birth</td>
				<td>:</td>
				<td>19/09/1998</td>
			</tr>
		</table>	
        <hr/>
        <a href="../write/edit_profile.html">Edit Profile</a>	
	</form>
</fieldset>