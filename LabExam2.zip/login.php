<?php
	session_start();
	$con = mysql_connect("localhost","root","");
	mysql_select_db("registration",$con);
	if(isset($_POST['submit'])){
		$username = $_POST['username'];
		$password = $_POST['password'];
	
		$sql = mysql_query("Select * from Informations where username='$username' && password='$password'");
		$rowcount = mysql_num_rows($sql);
		if($rowcount == true){
			echo "login successful";
			$_SESSION["username"]=$username;
			
			header("location:loggedin_layout.php");
		}
		else{
			echo "login unsuccessful";
		}
	}

?>


<fieldset>
    <legend><b>LOGIN</b></legend>
    <form action="#" method="post">
        <table>
            <tr>
                <td>User Name</td>
				<td>:</td>
                <td><input type="text" name="username"></td>
            </tr>
            <tr>
                <td>Password</td>
				<td>:</td>
                <td><input type="password" name="password"></td>
            </tr>
        </table>
        <hr />
		<input name="remember" type="checkbox">Remember Me
		<br/><br/>
        <input type="submit" name="submit" value="Submit">        
		<a href="forgot_password.html">Forgot Password?</a>
    </form>
</fieldset>