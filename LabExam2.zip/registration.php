


<?php

	if(isset($_POST['submit'])){
		
		if($_POST['name']==""){
			$error_msg['name'] = "Name Is Required";
		}
		if($_POST['email']==""){
			$error_msg['email'] = "email Is Required";
		}
		if($_POST['userName']==""){
			$error_msg['userName'] = "userName Is Required";
		}
		if($_POST['password']==""){
			$error_msg['password'] = "password Is Required";
		}
		if($_POST['confirmPassword']==""){
			$error_msg['confirmPassword'] = "confirmPassword Is Required";
		}
		if($_POST['gender']==""){
			$error_msg['gender'] = "gender Is Required";
		}
		if($_POST['password'] != $_POST['confirmPassword']){
			$error_msg['confirmPassword'] = "confirmPassword Is not matched";
		}
		if(!empty($_POST['name'])){
			if(!empty($_POST['email'])){
				if(!empty($_POST['userName'])){
					if(!empty($_POST['password'])){
						if(!empty($_POST['gender'])){
							$con = mysql_connect("localhost", "root", "");
								if(!$con){
									die("can't connect: ".mysql_error());
								}
								mysql_select_db("registration",$con);
								
								$sql = "INSERT INTO Informations (Name, Email, UserName, Password, Gender) VALUES ('$_POST[name]','$_POST[email]','$_POST[userName]','$_POST[password]','$_POST[gender]')";
									
									
								if(mysql_query($sql,$con)){
									echo "succesfully inserted";
								}
								
								
								mysql_close($con);
								
								
						}
					}
				}
			}
		}
		else header ("location:registration.php");
		
	} 



?>



<fieldset>
    <legend><b>REGISTRATION</b></legend>
	<form method = "post" action="registration.php">
		<br/>
		<table width="100%" cellpadding="0" cellspacing="0">
			<tr>
				<td>Name</td>
				<td>:</td>
				<td><input name="name" type="text" required>
				<?php
					if(isset($error_msg['name'])){
							echo $error_msg['name'];
					}
					?>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td>
					<input name="email" type="text" required>
					<abbr title="hint: sample@example.com"><b>i</b></abbr>
					<?php
						if(isset($error_msg['email'])){
								echo $error_msg['email'];
						}
					?>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>User Name</td>
				<td>:</td>
				<td><input name="userName" type="text" required>
				<?php
					if(isset($error_msg['userName'])){
						echo $error_msg['userName'];
					}
				?>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Password</td>
				<td>:</td>
				<td><input name="password" type="password" required>
				<?php
					if(isset($error_msg['password'])){
						echo $error_msg['password'];
					}
				?>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Confirm Password</td>
				<td>:</td>
				<td><input name="confirmPassword" type="password" required>
				<?php
					if(isset($error_msg['confirmPassword'])){
						echo $error_msg['confirmPassword'];
					}
				?>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td colspan="3">
					<fieldset>
						<legend>Gender</legend>    
						<input name="gender" type="radio" value="male">Male
						<input name="gender" type="radio"value="female">Female
						<input name="gender" type="radio" value="other">Other<br/>
						<?php
							if(isset($error_msg['gender'])){
								echo $error_msg['gender'];
							}
						?>
					</fieldset>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td colspan="3">
					<fieldset>
						<legend>Date of Birth</legend>    
						<input type="text" size="2" />/
						<input type="text" size="2" />/
						<input type="text" size="4" />
						<font size="2"><i>(dd/mm/yyyy)</i></font>
					</fieldset>
				</td>
				<td></td>
			</tr>
		</table>
		<hr/>
		<input type="submit" name="submit" value="Submit">
		<input type="reset" name="reset">
	</form>
</fieldset>