<?php
	session_start();
	$con = mysql_connect("localhost","root","");
	mysql_select_db("registration",$con);
	if(isset($_POST['submit'])){
		$password = $_POST['password'];
		$newpassword = $_POST['newpassword'];
		$retypenewpassword = $_POST['retypenewpassword'];
		if($password != $newpassword && $newpassword == $retypenewpassword){
			$sql = mysql_query("Select * from Informations where password='$password'");
			$rowcount = mysql_num_rows($sql);
			if($rowcount == true){
				echo "login successful"; 
				echo "<br/>";
				$_SESSION["newpassword"]=$newpassword;
				$sql="UPDATE Informations SET password='$newpassword' WHERE UserName='$_SESSION[username]' ";
				if(mysql_query($sql,$con)){
					echo "updated succesfully";
				
					header("location:loggedin_layout.php");
				}
			
				else{
					echo "update unsuccessful";
				}
			}
			else{
				echo " unsuccessful attempt. try again";
			}
			
		}
		else{
			echo "login unsuccessful";
		}
		
	}
?>

<fieldset>
    <legend><b>CHANGE PASSWORD</b></legend>
    <form method="post" action="#">
        <table>
            <tr>
                <td><font size="3">Current Password</font></td>
				<td>:</td>
                <td><input type="password" name="password" /></td>
                <td></td>
            </tr>
            <tr>
                <td><font size="3" color="green">New Password</font></td>
				<td>:</td>
                <td><input type="password" name="newpassword" /></td>
                <td></td>
            </tr>
            <tr>
                <td><font size="3" color="red">Retype New Password</font></td>
				<td>:</td>
                <td><input type="password" name="retypenewpassword"/></td>
                <td></td>
            </tr>
        </table>
        <hr />
        <input type="submit" name= "submit" value="Submit" />
    </form>
</fieldset>