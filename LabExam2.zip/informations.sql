-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 01, 2018 at 06:40 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `informations`
--

CREATE TABLE `informations` (
  `Name` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `UserName` varchar(20) NOT NULL,
  `Password` int(11) NOT NULL,
  `Gender` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `informations`
--

INSERT INTO `informations` (`Name`, `Email`, `UserName`, `Password`, `Gender`) VALUES
('tonmoy', 'shoaibaaatonmoy01@gm', 'tonmoy', 12345, 'on'),
('mahin', 'mahin@gmail.com', 'mahin', 123456, 'male'),
('test', '', 'test', 234, 'male'),
('sajid', 'sajid@gmail.com', 'sajid', 12345, 'male'),
('shurid', 'shurid@gmail.com', 'shurid', 123, 'male'),
('shimmy', 'shimmy@gmail.com', 'shimmy', 135, 'female');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
