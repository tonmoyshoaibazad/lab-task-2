<html>
	<head>
		<title>Form Validation</title>
	</head>
	<body>
		<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>">
			<fieldset>
				<legend>CHANGE PASSWORD</legend>
				<table>
			`		<tr>
						<td>Current password:</td>
						<td>
						<input type="password" name="cpassword"  />
						</td>
					</tr>
					<tr>
						<td style=color:green> New Password:</td>
						<td>
						<input type="password" name="npassword" />
						</td>
					</tr>
					<tr>
						<td style=color:red> Retype New Password:</td>
						<td>
						<input type="password" name="rnpassword"  />
						</td>
					</tr>					
				</table>
				<hr/>
				
				<input type="submit" name="submit" value="submit"/>
				
			</fieldset>
		</form>
		
			<?php
				if($_POST['npassword'] != $_POST['cpassword'] && !empty($_POST['npassword']))
				{
					if($_POST['rnpassword'] == $_POST['npassword'] && !empty($_POST['rnpassword'] ))
							echo "Password changed";
					else
							echo "retype password should be matched";
				}
				else
				{echo "please enter a new password";}
			?>
	</body>
</html>