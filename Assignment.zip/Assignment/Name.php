<html>
	<head>
		<title>Form Validation</title>
	</head>
	<body>
		<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>">
			<fieldset>
				<legend>LOGIN</legend>
				<table>
			`		<tr>
						<td>User Name:</td>
						<td>
						<input type="text" name="name"   title="Must contain at least two characters" required />
						</td>
					</tr>
					<tr>
						<td>Password:</td>
						<td>
						<input type="Password" name="Password"  title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required />
						</td>
					</tr>				
				</table>
				<hr/>
				<input type="checkbox" name="checkbox"/>
				Remember Me
				<br/>
				
				<input type="submit" name="submit" value="submit"/>
				<a href="form.php">Forgot Password?</a>
			</fieldset>
		</form>
		
			<?php
			
				if(preg_match("/^[A-Za-z][A-Za-z0-9 -_]*[A-Za-z0-9 -_]$/",$_POST['name']))
				{
					echo "valid name"."<br/>";
				 if( !preg_match( "/^[A-Za-z0-9]$/", $_POST['Password'] || strlen( $_POST['Password']) < 8))
					{
						echo "Invalid password!";
					}
					else
						echo "submitted your data"."<br/>";
				}
					
				else
					echo "wrong name ";
			?>
					
			 
	</body>
</html>